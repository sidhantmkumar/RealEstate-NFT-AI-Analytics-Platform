
-- Create warehouse
CREATE OR REPLACE WAREHOUSE compute_wh
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 300
  AUTO_RESUME = TRUE;

-- Create database
CREATE OR REPLACE DATABASE residential_analysis_db;

-- Create schemas
CREATE OR REPLACE SCHEMA residential_analysis_db.staging;
CREATE OR REPLACE SCHEMA residential_analysis_db.curated;
CREATE OR REPLACE SCHEMA residential_analysis_db.metadata;
