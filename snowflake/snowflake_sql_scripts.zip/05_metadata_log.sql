
USE DATABASE residential_analysis_db;
USE SCHEMA metadata;

CREATE OR REPLACE TABLE data_load_log (
    LOG_ID INTEGER AUTOINCREMENT,
    LAYER_NAME STRING,
    FILE_NAME STRING,
    ROW_COUNT NUMBER,
    LOAD_TIMESTAMP TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert log entry example
INSERT INTO data_load_log (LAYER_NAME, FILE_NAME, ROW_COUNT)
VALUES
  ('raw','residential_raw.csv', (SELECT COUNT(*) FROM residential_analysis_db.staging.residential_raw)),
  ('curated','residential_curated', (SELECT COUNT(*) FROM residential_analysis_db.curated.residential_curated));
