
USE DATABASE residential_analysis_db;
USE SCHEMA staging;

CREATE OR REPLACE STAGE residential_stage
  FILE_FORMAT = (TYPE = CSV FIELD_OPTIONALLY_ENCLOSED_BY='"' SKIP_HEADER=1);

-- Place file into stage using UI or snowsql then:
-- COPY INTO residential_raw FROM @residential_stage;
