
-- Preview curated data
SELECT * FROM residential_analysis_db.curated.residential_curated LIMIT 20;

-- Preview metadata logs
SELECT * FROM residential_analysis_db.metadata.data_load_log;
